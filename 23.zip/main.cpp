#include <iostream>
using namespace std;

int main() {
int a = 6;
a = a - 3;
cout << a << endl; // №1
 
int b = a;
cout << b << endl; // №2
 
// В этом случае a + b является r-value 
cout << a + b << endl; // №3
 
cout << a << endl; // №4
 
int c;
cout << c << endl; // №5
}
