#include <iostream>
#include <cmath>
using namespace std;

double case1 (double a, double b, double c,double d) 
{
return (a/c)*(b/d)-((a*b-c)/(c*d));
} 

int main() {
  cout<<"Результаты для значений a=2.2 b=5.4 c=3.5 ." <<" "<< case1(2.2 , 5.4, 3.5, 2.7);
}