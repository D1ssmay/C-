#include <iostream>
#include <cmath>
using namespace std;

double case1 (double x, double y) 
{
return (sin(x)+cos(y)/cos(x)-sin(y))*tan(x*y);
} 

int main() {
  cout<<"Результаты для значений x=2.2 y=5.4 ." <<"= "<< case1(2.2 , 5.4);
}