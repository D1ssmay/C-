#include <iostream>
using namespace std;

int main() {
  //endl , cout и cin находятся в iostream
  cout << "Hello World!"<< endl;
  //теперь код читать стало легче
  cout << "It is so exciting!" << endl;
  // правда?
  cout << "Yeah!" << endl;
}
