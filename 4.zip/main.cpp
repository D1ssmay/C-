#include <iostream>
using namespace std;

int main()
{
    if(false)
    {
        std::cout << "If 1" << std::endl;
        int y;
        int x=6;
        x = 5;
        std::cout << x;
        std::cout << "Hello, world!" << std::endl;
        //Переход на следующую строку...
        std::cout << "Hello, world!" << std::endl;
    }
    else if (false)
    {
        std::cout << "If 2" << std::endl;
        int a = 6;
        a = a - 3;
        std::cout << a << std::endl; // №1
        int b = a;
        std::cout << b << std::endl; // №2
        // В этом случае a + b является r-value 
        std::cout << a + b << std::endl; // №3
        std::cout << a << std::endl; // №4
        int c=0;
        std::cout << c << std::endl; // №5
    }else if (false)
    {
        int a = 7;
        std::cout << "a is " << a << a << a << a << a;
    }
    else if (!false)
    {
        std::cout << "Enter a number: "; // просим пользователя ввести любое число
        int a = 0;
        std::cin >> a; // получаем пользовательское число и сохраняем его в переменную a
        std::cout << "You entered " << a << std::endl;
    }
    return 0;
}
